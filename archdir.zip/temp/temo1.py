# TODO

from cs50 import get_string

text = get_string("Text: ")

letter = 0
sentences = 0
words = 1

for i in text:
    if i.isalpha():
        letter += 1
    elif i == " ":
        words = words + 1
    elif i == "." or "!" or "?":
        sentences = sentences + 1

print("letter ", letter)
print("words ", words)
print("sentences ", sentences)


index = 0.0588 * (letter / words * 100) - 0.296 * (sentences / words * 100) - 15.8



if index < 1 :
    print("Before Grade 1")
elif index > 1 and index < 17:
    print("Grade", round(index))
else:
    print("Grade 16+")
